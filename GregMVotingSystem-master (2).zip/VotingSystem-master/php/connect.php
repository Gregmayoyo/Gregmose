<?php

    include '../config/config.inc.php';

    $conn = new mysqli($_VOTE['db_server'], $_VOTE['db_username'], $_VOTE['db_password'], $_VOTE['db_name'], $_VOTE['db_port']);

    
    

?>