<?php

    $_VOTE = array();

    $_VOTE['db_server'] = '127.0.0.1';
    $_VOTE['db_name'] = 'voting_system';
    $_VOTE['db_username'] = 'root';
    $_VOTE['db_password'] = "";
    $_VOTE['db_port'] = '3306'; //set to 3306 if you haven't changed the port in xampp/wamp server



?>