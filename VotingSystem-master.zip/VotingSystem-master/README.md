# Complete voting System
This is a Simple Voting system made with `HTML`, `CSS`, `JavaScript`, `PHP` and `MySQL`

## Dependencies
   - Install XAMPP



## Setting Up Environment
- Edit `config.inc.php` file in `config` folder to go with your development environment needs.



## Running the app
go to `http://127.0.0.1/` to load the index file

## Contributors 
- John Migwi
